package com.movie3.movie3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie3.movie3.entity.admin;

public interface adminrepo extends JpaRepository<admin,String> {
	
}
