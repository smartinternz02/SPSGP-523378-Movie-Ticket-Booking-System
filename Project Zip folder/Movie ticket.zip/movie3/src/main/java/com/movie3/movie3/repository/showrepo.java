package com.movie3.movie3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie3.movie3.entity.show;

public interface showrepo extends JpaRepository<show,Integer>{

}
