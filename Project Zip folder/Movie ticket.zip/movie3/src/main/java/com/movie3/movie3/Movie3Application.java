package com.movie3.movie3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Movie3Application {

	public static void main(String[] args) {
		SpringApplication.run(Movie3Application.class, args);
	}

}
