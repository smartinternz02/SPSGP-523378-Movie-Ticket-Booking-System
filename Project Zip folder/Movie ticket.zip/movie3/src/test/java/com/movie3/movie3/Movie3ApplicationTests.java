package com.movie3.movie3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Movie3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
